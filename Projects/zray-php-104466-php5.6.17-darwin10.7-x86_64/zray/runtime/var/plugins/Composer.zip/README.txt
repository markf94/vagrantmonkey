Z-Ray on Composer provides extra information on the Composer packages used on the page, and a full mapping of all the used classes.

*   Packages
    *   Lists all the Composer packages used on the page, with detailed information on each package, including: name, version, source, requirements, authors, and home page.
*   Class Map
    *   Provides a complete mapping of the classes used on the page, including the class name and the source file location.