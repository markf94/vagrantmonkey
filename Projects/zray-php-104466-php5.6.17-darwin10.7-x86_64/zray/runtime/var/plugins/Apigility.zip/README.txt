Z-Ray on Apigility provides insight into MVC authentication events and user identity role.

*   MVC Auth Events

*   Information on MVC authentication events, including events name and result

*   Identity Role

*   Information on the current user